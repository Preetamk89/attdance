﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbboxEvnType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.scheduleTimePicker = new System.Windows.Forms.DateTimePicker();
            this.txtDefaultEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbboxSendEmailOn = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboxSendReminder = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBilledHrs = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboxShowHistory = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBaseAddress = new System.Windows.Forms.TextBox();
            this.txtApiUsername = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtApiPassword = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtEmailTemplatePath = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIncludeRegion = new System.Windows.Forms.TextBox();
            this.txtCCEmail = new System.Windows.Forms.TextBox();
            this.BtnStartService = new System.Windows.Forms.Button();
            this.btnStopService = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmboxEmployees = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(380, 710);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "Save Config";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Schedule Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(642, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "EnvironmentType";
            // 
            // cmbboxEvnType
            // 
            this.cmbboxEvnType.FormattingEnabled = true;
            this.cmbboxEvnType.Items.AddRange(new object[] {
            "Development",
            "Production"});
            this.cmbboxEvnType.Location = new System.Drawing.Point(813, 22);
            this.cmbboxEvnType.Name = "cmbboxEvnType";
            this.cmbboxEvnType.Size = new System.Drawing.Size(353, 24);
            this.cmbboxEvnType.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Default Email Id";
            // 
            // scheduleTimePicker
            // 
            this.scheduleTimePicker.CustomFormat = "HH:mm";
            this.scheduleTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.scheduleTimePicker.Location = new System.Drawing.Point(198, 25);
            this.scheduleTimePicker.Name = "scheduleTimePicker";
            this.scheduleTimePicker.ShowUpDown = true;
            this.scheduleTimePicker.Size = new System.Drawing.Size(353, 22);
            this.scheduleTimePicker.TabIndex = 6;
            // 
            // txtDefaultEmail
            // 
            this.txtDefaultEmail.Location = new System.Drawing.Point(198, 71);
            this.txtDefaultEmail.Name = "txtDefaultEmail";
            this.txtDefaultEmail.Size = new System.Drawing.Size(353, 22);
            this.txtDefaultEmail.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(642, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Send Email on";
            // 
            // cmbboxSendEmailOn
            // 
            this.cmbboxSendEmailOn.FormattingEnabled = true;
            this.cmbboxSendEmailOn.Items.AddRange(new object[] {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"});
            this.cmbboxSendEmailOn.Location = new System.Drawing.Point(813, 67);
            this.cmbboxSendEmailOn.Name = "cmbboxSendEmailOn";
            this.cmbboxSendEmailOn.Size = new System.Drawing.Size(353, 24);
            this.cmbboxSendEmailOn.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Send Reminder Email on";
            // 
            // comboxSendReminder
            // 
            this.comboxSendReminder.FormattingEnabled = true;
            this.comboxSendReminder.Items.AddRange(new object[] {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"});
            this.comboxSendReminder.Location = new System.Drawing.Point(198, 127);
            this.comboxSendReminder.Name = "comboxSendReminder";
            this.comboxSendReminder.Size = new System.Drawing.Size(353, 24);
            this.comboxSendReminder.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Total Billed Hrs";
            // 
            // txtBilledHrs
            // 
            this.txtBilledHrs.Location = new System.Drawing.Point(198, 197);
            this.txtBilledHrs.Mask = "000";
            this.txtBilledHrs.Name = "txtBilledHrs";
            this.txtBilledHrs.Size = new System.Drawing.Size(353, 22);
            this.txtBilledHrs.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(642, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Show History";
            // 
            // comboxShowHistory
            // 
            this.comboxShowHistory.FormattingEnabled = true;
            this.comboxShowHistory.Items.AddRange(new object[] {
            "True",
            "False"});
            this.comboxShowHistory.Location = new System.Drawing.Point(813, 195);
            this.comboxShowHistory.Name = "comboxShowHistory";
            this.comboxShowHistory.Size = new System.Drawing.Size(353, 24);
            this.comboxShowHistory.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 254);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Base Address";
            // 
            // txtBaseAddress
            // 
            this.txtBaseAddress.Location = new System.Drawing.Point(198, 249);
            this.txtBaseAddress.Name = "txtBaseAddress";
            this.txtBaseAddress.Size = new System.Drawing.Size(353, 22);
            this.txtBaseAddress.TabIndex = 18;
            // 
            // txtApiUsername
            // 
            this.txtApiUsername.Location = new System.Drawing.Point(813, 244);
            this.txtApiUsername.Name = "txtApiUsername";
            this.txtApiUsername.Size = new System.Drawing.Size(353, 22);
            this.txtApiUsername.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(642, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "API Login Username ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "API Login Password";
            // 
            // txtApiPassword
            // 
            this.txtApiPassword.Location = new System.Drawing.Point(198, 294);
            this.txtApiPassword.Name = "txtApiPassword";
            this.txtApiPassword.Size = new System.Drawing.Size(353, 22);
            this.txtApiPassword.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(642, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(150, 17);
            this.label11.TabIndex = 23;
            this.label11.Text = "CC To Reminder Email";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(642, 299);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 17);
            this.label12.TabIndex = 25;
            this.label12.Text = "Email Template Path";
            // 
            // txtEmailTemplatePath
            // 
            this.txtEmailTemplatePath.Location = new System.Drawing.Point(813, 299);
            this.txtEmailTemplatePath.Name = "txtEmailTemplatePath";
            this.txtEmailTemplatePath.Size = new System.Drawing.Size(353, 22);
            this.txtEmailTemplatePath.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 348);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 17);
            this.label13.TabIndex = 27;
            this.label13.Text = "Include Region";
            // 
            // txtIncludeRegion
            // 
            this.txtIncludeRegion.Location = new System.Drawing.Point(198, 343);
            this.txtIncludeRegion.Name = "txtIncludeRegion";
            this.txtIncludeRegion.Size = new System.Drawing.Size(356, 22);
            this.txtIncludeRegion.TabIndex = 28;
            // 
            // txtCCEmail
            // 
            this.txtCCEmail.Location = new System.Drawing.Point(813, 108);
            this.txtCCEmail.Multiline = true;
            this.txtCCEmail.Name = "txtCCEmail";
            this.txtCCEmail.Size = new System.Drawing.Size(353, 73);
            this.txtCCEmail.TabIndex = 29;
            // 
            // BtnStartService
            // 
            this.BtnStartService.Location = new System.Drawing.Point(565, 710);
            this.BtnStartService.Name = "BtnStartService";
            this.BtnStartService.Size = new System.Drawing.Size(138, 34);
            this.BtnStartService.TabIndex = 30;
            this.BtnStartService.Text = "Start Service";
            this.BtnStartService.UseVisualStyleBackColor = true;
            this.BtnStartService.Click += new System.EventHandler(this.btnStartService_Click);
            // 
            // btnStopService
            // 
            this.btnStopService.Location = new System.Drawing.Point(789, 710);
            this.btnStopService.Name = "btnStopService";
            this.btnStopService.Size = new System.Drawing.Size(167, 34);
            this.btnStopService.TabIndex = 31;
            this.btnStopService.Text = "Stop Service";
            this.btnStopService.UseVisualStyleBackColor = true;
            this.btnStopService.Click += new System.EventHandler(this.btnStopService_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmboxEmployees);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.scheduleTimePicker);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtIncludeRegion);
            this.groupBox1.Controls.Add(this.txtCCEmail);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.cmbboxEvnType);
            this.groupBox1.Controls.Add(this.txtEmailTemplatePath);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtDefaultEmail);
            this.groupBox1.Controls.Add(this.txtApiPassword);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cmbboxSendEmailOn);
            this.groupBox1.Controls.Add(this.txtApiUsername);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtBaseAddress);
            this.groupBox1.Controls.Add(this.comboxSendReminder);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboxShowHistory);
            this.groupBox1.Controls.Add(this.txtBilledHrs);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(26, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1194, 379);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "APP SETTINGS";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(642, 343);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(130, 17);
            this.label20.TabIndex = 30;
            this.label20.Text = "Exclude Employees";
            // 
            // cmboxEmployees
            // 
            this.cmboxEmployees.FormattingEnabled = true;
            this.cmboxEmployees.Location = new System.Drawing.Point(813, 339);
            this.cmboxEmployees.Name = "cmboxEmployees";
            this.cmboxEmployees.Size = new System.Drawing.Size(353, 24);
            this.cmboxEmployees.TabIndex = 31;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 814);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnStopService);
            this.Controls.Add(this.BtnStartService);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Attendance Reconciliation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbboxEvnType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker scheduleTimePicker;
        private System.Windows.Forms.TextBox txtDefaultEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbboxSendEmailOn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboxSendReminder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox txtBilledHrs;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboxShowHistory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBaseAddress;
        private System.Windows.Forms.TextBox txtApiUsername;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtApiPassword;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtEmailTemplatePath;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIncludeRegion;
        private System.Windows.Forms.TextBox txtCCEmail;
        private System.Windows.Forms.Button BtnStartService;
        private System.Windows.Forms.Button btnStopService;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmboxEmployees;
        private System.Windows.Forms.Label label20;
    }
}

