﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceProcess;
using AttendanceReconciliationService;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public string constr = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;
        Dictionary<string, string> appConfigs = new Dictionary<string, string>();
        public Form1()
        {
            InitializeComponent();
            DefaultAssignValue();
            
        }

        private void DefaultAssignValue()
        {
            try
            {
                DataTable dtConfig = new DataTable();
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_getAllAppConfig", con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(dtConfig);
                            con.Close();
                        }
                    }
                }
                foreach (DataRow dr in dtConfig.Rows)
                {
                    appConfigs.Add(dr["Key"].ToString(), dr["Value"].ToString());
                }

                if (appConfigs.Count > 0)
                {
                    scheduleTimePicker.Value = Convert.ToDateTime(appConfigs["ScheduledTime"]);
                    cmbboxEvnType.SelectedItem = appConfigs["EnvironmentType"];
                    txtDefaultEmail.Text = appConfigs["defaultEmailSent"];
                    cmbboxSendEmailOn.SelectedItem = appConfigs["SendAttendenceEmailOn"];
                    comboxSendReminder.SelectedItem = appConfigs["SendReminderEmailOn"];
                    txtBilledHrs.Text = appConfigs["TotalBilledHours"];
                    comboxShowHistory.SelectedItem = appConfigs["ShowHistory"];
                    txtApiUsername.Text = appConfigs["NetworkUsername"];
                    txtApiPassword.Text = appConfigs["NetworkPassword"];
                    txtBaseAddress.Text = appConfigs["BaseAddress"];
                    txtCCEmail.Text = appConfigs["reminderEmailCC"];
                    txtEmailTemplatePath.Text = appConfigs["EmailTemplate"];
                    txtIncludeRegion.Text = appConfigs["IncludeRegion"];
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        private void SaveConfig()
        {
            try
            {
                
                appConfigs["ScheduledTime"] = Convert.ToDateTime(scheduleTimePicker.Text).ToString("HH:mm");
                appConfigs["EnvironmentType"] = Convert.ToString(cmbboxEvnType.SelectedItem);
                appConfigs["defaultEmailSent"] = txtDefaultEmail.Text;
                appConfigs["SendAttendenceEmailOn"]= Convert.ToString(cmbboxSendEmailOn.SelectedItem);
                appConfigs["SendReminderEmailOn"]= Convert.ToString(comboxSendReminder.SelectedItem);
                appConfigs["TotalBilledHours"]= Convert.ToString(txtBilledHrs.Text);
                appConfigs["ShowHistory"]= Convert.ToString(comboxShowHistory.SelectedItem);
                appConfigs["NetworkUsername"]= txtApiUsername.Text;
                appConfigs["NetworkPassword"]= txtApiPassword.Text;
                appConfigs["BaseAddress"]= Convert.ToString(txtBaseAddress.Text);
                appConfigs["reminderEmailCC"]= txtCCEmail.Text;
                appConfigs["EmailTemplate"]= Convert.ToString(txtEmailTemplatePath.Text);
                appConfigs["IncludeRegion"]=txtIncludeRegion.Text;

                foreach (var appConfig in appConfigs)
                {
                    using (SqlConnection con = new SqlConnection(constr))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_UpdateAppConfiguration", con))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@key", appConfig.Key);
                            cmd.Parameters.AddWithValue("@value", appConfig.Value);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void save_Click(object sender, EventArgs e)
        {
            SaveConfig();
            MessageBox.Show("Saved Successfully","Saved");
        }

        private void btnStartService_Click(object sender, EventArgs e)
        {
            RunService("start");
            BtnStartService.Enabled = false;
            btnStopService.Enabled = true;
            MessageBox.Show("Service Started Successfully", "Service Message");
        }

        private void btnStopService_Click(object sender, EventArgs e)
        {
            RunService("stop");
            btnStopService.Enabled = false;
            BtnStartService.Enabled = true;
            MessageBox.Show("Service Stopped Successfully", "Service Message");
        }

        private void RunService( string action)
        {
            ServiceController sc = new ServiceController("AttendanceReconciliationService");
            
            if(sc.Status.Equals(ServiceControllerStatus.Running) && action =="stop")
            {
                sc.Stop();
            }
            else if (((sc.Status.Equals(ServiceControllerStatus.Stopped)) ||
                  (sc.Status.Equals(ServiceControllerStatus.StopPending)) ) && action == "start")
            {
                sc.Start();
            }
            else
                sc.Stop();
        }
    }
}
