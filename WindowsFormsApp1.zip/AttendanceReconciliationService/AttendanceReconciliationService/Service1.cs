﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net.Configuration;
using System.Net.Http;
using System.Net;
using System.Net.Http.Headers;
using Dapper;

namespace AttendanceReconciliationService
{
    public partial class Service1 : ServiceBase
    {
        public string constr = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;
        Dictionary<string, string> appConfigs = new Dictionary<string, string>();
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            this.WriteToFile("Attendance Reconciliation Service started {0}");
            DebugMode();
            LoadConfiguration();
            this.ScheduleService();
        }

        private void LoadConfiguration()
        {
            DataTable dtConfig = new DataTable();
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("usp_getAllAppConfig", con))
                {
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        da.Fill(dtConfig);
                        con.Close();
                    }
                }
            }
            foreach (DataRow dr in dtConfig.Rows)
            {
                appConfigs.Add(dr["Key"].ToString(), dr["Value"].ToString());
            }
        }

        protected override void OnStop()
        {
            this.WriteToFile("Attendance Reconciliation Service stopped {0}");
            this.Schedular.Dispose();
        }

        private Timer Schedular;

        public void ScheduleService()
        {
            try
            {
                this.WriteToFile("ScheduleService1");
                Schedular = new Timer(new TimerCallback(SchedularCallback));
                string mode = ConfigurationManager.AppSettings["Mode"].ToUpper();
                this.WriteToFile("ScheduleService2");
                //Set the Default Time.
                DateTime scheduledTime = DateTime.MinValue;

                if (mode == "DAILY")
                {
                    //Get the Scheduled Time from AppSettings.

                    scheduledTime = DateTime.Parse(appConfigs["ScheduledTime"]);
                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next day.
                        scheduledTime = scheduledTime.AddDays(1);
                    }
                }




                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds(s)", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);

                this.WriteToFile("Attendance Reconciliation Service scheduled to run after: " + schedule + " {0}");

                //Get the difference in Minutes between the Scheduled and Current Time.
                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);

                //Change the Timer's Due Time.
                Schedular.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                WriteToFile("Attendance Reconciliation Service Error on: {0} " + ex.Message + ex.StackTrace);

                //Stop the Windows Service.
                using (System.ServiceProcess.ServiceController serviceController = new System.ServiceProcess.ServiceController("AttendanceReconciliationService"))
                {
                    serviceController.Stop();
                }
            }
        }

        private void SendEmployeeEmail(DateTime StartDate, DateTime EndDate)
        {
            try
            { 

                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_getMissingWeekDetails", con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@startDate", StartDate);
                            cmd.Parameters.AddWithValue("@endDate", EndDate);
                            da.Fill(dt);
                            con.Close();

                        }

                    }
                }
                if (dt.Rows.Count > 0)
                    SendEmail(dt, false);
            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in SendEmployeeEmail " + ex.Message + ", Message: " + ex.StackTrace);
            }
        }
        private void SendEmail(DataTable dt, bool isReminderEmail)
        {
            try
            {
                Configuration oConfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
               // var mailSettings = oConfig.GetSectionGroup("system.net/mailSettings") as MailSettingsSectionGroup;
                string emailSubjectpath, emailBodypath, strMsgSubject = string.Empty;
                emailSubjectpath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, appConfigs["EmailTemplate"] + "subject.txt");
                string[] ccMailAddress = appConfigs["reminderEmailCC"].Split(',');

                strMsgSubject = File.ReadAllText(emailSubjectpath);
                this.WriteToFile("SendEmail");
                foreach (DataRow row in dt.Rows)
                {
                    //string name = row["FirstName"].ToString() + " " + row["LastName"].ToString();
                    var query = string.Empty;
                    string email = string.Empty;
                    DateTime startDate = Convert.ToDateTime(row["Startdate"]);
                    DateTime endDate = Convert.ToDateTime(row["EndDate"]);
                    string username = row["FirstName"].ToString() + ' ' + row["Lastname"].ToString();
                    string env = appConfigs["EnvironmentType"].ToString();
                    if (env.ToLower() == "development")
                        email = appConfigs["defaultEmailSent"].ToString();
                    else
                        email = row["Email"].ToString();

                    MailMessage mm = new MailMessage();
                    mm.To.Add(email);
                    mm.From = new MailAddress(appConfigs["smtpFromEmail"]);
                    mm.Subject = string.Format(strMsgSubject, startDate.ToString("MM-dd-yyyy"), endDate.ToString("MM-dd-yyyy"));
                    if (isReminderEmail)
                    {
                        foreach (var MailAddress in ccMailAddress)
                            mm.CC.Add(MailAddress);
                        mm.Subject = "Reminder: " + string.Format(strMsgSubject, startDate.ToString("MM-dd-yyyy"), endDate.ToString("MM-dd-yyyy"));
                    }
                   
                    string[] dates = new string[] { };
                    StringBuilder TimeSheetHistory = new StringBuilder();
                    string emailBody = string.Empty;
                    Boolean ShowHistory = Convert.ToBoolean(appConfigs["ShowHistory"].ToString());
                    string historyMessage = string.Empty;

                    if (!string.IsNullOrEmpty(Convert.ToString(row["MissingDate"])))
                    {

                        emailBodypath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, appConfigs["EmailTemplate"] + "TimesheetMissingEmail.html");
                        dates = Convert.ToString(row["MissingDate"]).Split(',');
                        foreach (var item in dates)
                        {
                            TimeSheetHistory.AppendFormat("<li>" + Convert.ToDateTime(item).ToString("MM-dd-yyyy") + "</li>");
                        };

                    }
                    else
                    {
                        emailBodypath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, appConfigs["EmailTemplate"] + "TimesheetLessHoursEmail.html");
                        TimeSheetHistory.Append(Convert.ToString(appConfigs["TotalBilledHours"]));

                    }
                    if (ShowHistory)
                    {
                        historyMessage = GetHistoryDetails(startDate, endDate, Convert.ToInt32(row["EmpId"].ToString()));
                    }
                    emailBody = PopulateBody(username, startDate.ToString("MM-dd-yyyy"), endDate.ToString("MM-dd-yyyy"), TimeSheetHistory.ToString(), emailBodypath, historyMessage, Convert.ToString(row["TotalHrs"]));

                   mm.Body = emailBody.ToString();

                    mm.IsBodyHtml = true;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = appConfigs["networkHost"];
                    smtp.EnableSsl = Convert.ToBoolean(appConfigs["mailEnableSSl"]);
                    System.Net.NetworkCredential credentials = new System.Net.NetworkCredential();
                    credentials.UserName = appConfigs["mailUsername"];
                    credentials.Password = appConfigs["mailPassword"];
                    smtp.UseDefaultCredentials = Convert.ToBoolean(appConfigs["mailDefaultCrenditails"]);
                    smtp.Credentials = credentials;
                    smtp.Send(mm);
                    if (!isReminderEmail)
                    {
                        if (row["IsSent"].ToString() == "False")
                        {
                            this.WriteToFile("Email sent successfully to: " + email);
                            query = "UPDATE DateHrsMissingDetails SET isSent = 1 WHERE Id = " + row["id"].ToString();
                            using (SqlConnection con = new SqlConnection(constr))
                            {
                                using (SqlCommand cmd = new SqlCommand(query))
                                {
                                    cmd.Connection = con;
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                }
                            }
                        }
                    }
                    else
                    {
                        if (row["isReminderSent"].ToString() == "False")
                        {
                            this.WriteToFile("Email sent successfully to: " + email);
                            query = "UPDATE DateHrsMissingDetails SET isReminderSent = 1 WHERE Id = " + row["id"].ToString();
                            using (SqlConnection con = new SqlConnection(constr))
                            {
                                using (SqlCommand cmd = new SqlCommand(query))
                                {
                                    cmd.Connection = con;
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                }
                            }
                        }
                    }

                    WriteToFile("Email sent successfully to " + email);
                    this.ScheduleService();

                }
            }
            catch (Exception ex)
            {
                WriteToFile("Send Email Error on: {0} " + ex.Message + " Message: " + ex.StackTrace);
            }
        }

        private void SchedularCallback(object e)
        {
            this.WriteToFile("SchedularCallback");
            this.WriteToFile("Attendance Reconciliation Service Log: {0}");

            

            string SendAttendenceEmailOn = appConfigs["SendAttendenceEmailOn"];

            DateTime date = DateTime.Now;
            DateTime startDate = date.AddDays(-(int)date.DayOfWeek - 7);
            DateTime endDate = startDate.AddDays(6);
            
            if (DateTime.Now.DayOfWeek == (DayOfWeek)Enum.Parse(typeof(DayOfWeek), SendAttendenceEmailOn))
            {
                loadEmployeeData();
                loadBilledHours(startDate, endDate);
                SendEmployeeEmail(startDate, endDate);
            }
            string SendReminderEmailOn = appConfigs["SendReminderEmailOn"];
            if (DateTime.Now.DayOfWeek == (DayOfWeek)Enum.Parse(typeof(DayOfWeek), SendReminderEmailOn))
            {

                sendReminderEmail(startDate, endDate);
            }
        }

        private void sendReminderEmail(DateTime StartDate ,DateTime EndDate)
        {
            try
            {
                DataTable dt = new DataTable();
                this.WriteToFile("sendReminderEmail");
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_getUpdatedListForReminder", con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@startDate", StartDate);
                            cmd.Parameters.AddWithValue("@endDate", EndDate);
                            da.Fill(dt);
                            con.Close();

                        }

                    }
                }
                if (dt.Rows.Count > 0)
                    SendEmail(dt, true);
            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in SendReminderEmail " + ex.Message + ", Message: " + ex.StackTrace);
            }
        }

        private void loadBilledHours(DateTime startDate, DateTime currentDate)
        {
            try
            {

                HttpClient client = getHttpClient();
                var regions = appConfigs["IncludeRegion"].ToString().Split(',').ToList();
                client.BaseAddress = new Uri("http://support.itdev.neudesic.com/dev/neudesic.services.tbs/");

                for (var date = startDate.Date; date <= currentDate.Date; date = date.AddDays(1))
                {
                    HttpResponseMessage response = client.GetAsync("api/FinanceQueue?mode=3&Startworkdate=" + date.ToString("MM-dd-yyyy") + "&endworkdate=" + date.ToString("MM-dd-yyyy")).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        // DataTable dtbilledHrs = response.Content.ReadAsAsync<BilledHours>().Result.AsEnumerable().Where(x=> regions.Contains(x.Field<string>("RegionName")));
                        //IEnumerable<Employee> employeeList = response.Content.ReadAsAsync<IEnumerable<Employee>>().Result.Where(x => x.RegionName != null);
                        //IEnumerable<Employee> Employees = employeeList.Where(x => regions.Contains(x.RegionName));
                        DataTable dtbilledHrs = response.Content.ReadAsAsync<DataTable>().Result.AsEnumerable().Where(y=> y.Field<string>("RegionName") != null).Where(x => regions.Contains(x.Field<string>("RegionName"))).CopyToDataTable();
                        CopyBilledHrsData(dtbilledHrs);
                        this.WriteToFile("CopyEmployeeData reference");
                    }
                    else
                    {
                        this.WriteToFile("Error in LoadEmployeeData " + response.StatusCode + ", Message: " + response.ReasonPhrase);
                    }
                }

            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in loadBilledHours " + ex.Message.ToString() + " Message: " + ex.StackTrace.ToString());
            }
        }

        private void CopyBilledHrsData(DataTable dtbilledHrs)
        {
            try
            {
                if (dtbilledHrs.Rows.Count > 0)
                {
                    using (SqlConnection con = new SqlConnection(constr))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_Add_or_update_billedHrs", con))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@tblbilledHrs", dtbilledHrs);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in CopyBilledHrsData " + ex.Message.ToString() + "Message: " + ex.StackTrace);
            }
        }

        private void WriteToFile(string text)
        {
            string path = "D:\\ServiceLog.txt";
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine(string.Format(text, DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt")));
                writer.Close();
            }
        }

        private void loadEmployeeData()
        {
            try
            {
                this.WriteToFile("loadEmployeeData");
                var regions = appConfigs["IncludeRegion"].ToString().Split(',').ToList();
                var excludePractice = ConfigurationManager.AppSettings["ExcludePractice"].Split(',').ToList();
                HttpClient client = getHttpClient();
                HttpResponseMessage response = client.GetAsync("api/getallemployees/true").Result;
                if (response.IsSuccessStatusCode)
                {
                    IEnumerable<Employee> employeeList = response.Content.ReadAsAsync<IEnumerable<Employee>>().Result.Where(x => x.RegionName != null);
                    IEnumerable<Employee> excludeEmployee = employeeList.Where(x => excludePractice.Contains(x.PracticeName));
                    IEnumerable<Employee> Employees = employeeList.Where(x => regions.Contains(x.RegionName)).Except(excludeEmployee);
                    
                    
                    CopyEmployeeData(Employees);
                    this.WriteToFile("CopyEmployeeData reference");
                }
                else
                {
                    this.WriteToFile("Error in LoadEmployeeData " + response.StatusCode + ", Message: " + response.ReasonPhrase);
                }
            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in LoadEmployeeData " + ex.Message.ToString());
            }
        }


        private void CopyEmployeeData(IEnumerable<Employee> employees)
        {
            try
            {
                this.WriteToFile("CopyEmployeeData");
                using (SqlConnection con = new SqlConnection(constr))
                {
                    con.Open();

                    DataTable dtEmployee = new DataTable();
                    var employeeList = con.Query<Employee>("usp_getAllEmployees", commandType: CommandType.StoredProcedure).AsEnumerable();

                    /*Testing Purpose */
                    //Employee emp = new Employee();
                    //emp.EmployeeID = 9999;
                    //emp.FirstName = "ak";
                    //emp.LastName = "ak";
                    //emp.Login = "ak";
                    //emp.PracticeName = "ak";
                    //emp.RegionName = "ak";
                    //emp.PracticeID = 89;
                    //emp.RegionID = 89;
                    //emp.ReportsToID = "78";

                    //employees = employees.Concat(new Employee[] { emp });

                    var filterListed = employees.Except(employeeList, new EmployeeComparer());
                    dtEmployee = ConvertToTable(filterListed);

                    if (dtEmployee.Rows.Count > 0)
                    {
                        using (SqlBulkCopy objbulk = new SqlBulkCopy(con))
                        {
                            this.WriteToFile("SqlBulkCopy");
                            objbulk.DestinationTableName = "Employee";
                            //Mapping Table column  

                            objbulk.ColumnMappings.Add("EmployeeID", "EmployeeID");
                            objbulk.ColumnMappings.Add("FirstName", "FirstName");
                            objbulk.ColumnMappings.Add("LastName", "LastName");
                            objbulk.ColumnMappings.Add("Login", "Login");
                            objbulk.ColumnMappings.Add("RegionID", "RegionID");
                            objbulk.ColumnMappings.Add("PracticeID", "PracticeID");
                            objbulk.ColumnMappings.Add("PracticeName", "PracticeName");
                            objbulk.ColumnMappings.Add("RegionName", "RegionName");
                            objbulk.ColumnMappings.Add("ReportsToID", "ReportsToID");
                            //inserting bulk Records into DataBase   
                            objbulk.WriteToServer(dtEmployee);
                        }
                    }
                    con.Close();
                    this.WriteToFile("completed");
                }
            }
            catch (Exception ex)
            {
                this.WriteToFile("Error in CopyEmployeeData" + ex.Message.ToString() + "Message: " + ex.StackTrace);
            }
        }

        private HttpClient getHttpClient()
        {
            string username = appConfigs["NetworkUsername"];
            string password = appConfigs["NetworkPassword"];
            var credentials = new NetworkCredential(username, password);
            var handler = new HttpClientHandler { Credentials = credentials };
            HttpClient client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Add(
               new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri(appConfigs["BaseAddress"]);
            this.WriteToFile(client.BaseAddress.ToString());
            return client;
        }

        [Conditional("DEBUG_SERVICE")]
        private static void DebugMode()
        {
            Debugger.Break();
        }
        private static DataTable ConvertToTable<T>(IEnumerable<T> list)
        {
            DataTable table = CreateTable<T>();
            Type entityType = typeof(T);
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

            foreach (T item in list)
            {
                DataRow row = table.NewRow();

                foreach (PropertyDescriptor prop in properties)
                {
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }

                table.Rows.Add(row);
            }

            return table;
        }

        private static DataTable CreateTable<T>()
        {
            Type entityType = typeof(T);
            DataTable table = new DataTable(entityType.Name);
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

            foreach (PropertyDescriptor prop in properties)
            {
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(
            prop.PropertyType) ?? prop.PropertyType);
            }

            return table;
        }

        private string GetHistoryDetails(DateTime startDate, DateTime endDate, int EmployeeID)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_getHistoryDetails", con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@startDate", startDate);
                            cmd.Parameters.AddWithValue("@endDate", endDate);
                            cmd.Parameters.AddWithValue("@employee", EmployeeID);
                            da.Fill(dt);
                            con.Close();

                        }

                    }
                }
                StringBuilder strbuilder = new StringBuilder();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        string missedDate = Convert.ToString(row["missedDate"]) == null ? string.Empty : Convert.ToDateTime(row["missedDate"]).ToString("MM-dd-yyyy");
                        string weekStartDate = Convert.ToDateTime(row["Startdate"]).ToString("MM-dd-yyyy");
                        string weekEndDate = Convert.ToDateTime(row["EndDate"]).ToString("MM-dd-yyyy");
                        string Totalhrs = Convert.ToString(row["TotalHrs"]) == null ? "0" : Convert.ToString(row["TotalHrs"]);
                        if (!String.IsNullOrEmpty(missedDate))
                        {
                            strbuilder.AppendFormat("<li>{0} - No data avaialble </li>", missedDate);
                        }
                        else
                        {
                            strbuilder.AppendFormat("<li>{0} - {1} week available hours ({2} hrs) is less than {3}hrs </li>", weekStartDate, weekEndDate, Totalhrs, Convert.ToString(appConfigs["TotalBilledHours"]));
                        }
                    }
                }
                else
                {
                    strbuilder.Append("<li>None</li>");
                }

                return strbuilder.ToString();
            }

            catch (Exception ex)
            {
                this.WriteToFile("Error in GetHistoryDetails" + ex.Message.ToString() + "Message: " + ex.StackTrace);
                return string.Empty;
            }
        }

        private string PopulateBody(string name, string startWeekDate, string endWeekDate, string timesheetDetails, string path, string HistoryDetails,string billedHrs)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(path))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{0}", name);
            body = body.Replace("{1}", startWeekDate);
            body = body.Replace("{2}", endWeekDate);
            body = body.Replace("{3}", timesheetDetails);
            body = body.Replace("{4}", HistoryDetails);
            body = body.Replace("{5}", billedHrs);
            return body;
        }

    }
}
