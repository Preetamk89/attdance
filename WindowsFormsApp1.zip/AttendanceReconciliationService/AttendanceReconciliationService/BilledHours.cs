﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceReconciliationService
{
    public class BilledHours
    {
        public bool HasEntryHistory {get; set;}
        public int BilledHourId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int ProjectTypeID { get; set; }
        public DateTime WorkDate { get; set; }
        public int ChargeTypeId { get; set; }
        public string ChargeType { get; set; }
        public int TimeStatusId { get; set; }
        public string TimeStatus { get; set; }
        public int WorkWeekId { get; set; }
        public string Description { get; set; }
        public string EmployeeTitle { get; set; }
        public int  ProjectManagerId { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string RegionName { get; set; }
        public decimal EntryHours { get; set; }
        public DateTime SubmittedAt { get; set; }
        public bool HasApproved { get; set; }
        public int? StandardCost { get; set; }
        public int? Rate { get; set; }
        public int? SalesRepId { get; set; }
        public string SalesRep { get; set; }

    }
}
