﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceReconciliationService
{
   public class EmployeeComparer : IEqualityComparer<Employee>
    {

        public bool Equals(Employee x, Employee y)
        {
            //Check whether the objects are the same object. 
            if (Object.ReferenceEquals(x, y)) return true;

            //Check whether the products' properties are equal. 
            return x != null && y != null && x.EmployeeID.Equals(y.EmployeeID); // && x.Name.Equals(y.Name);
        }

        public int GetHashCode(Employee obj)
        {

            //Get hash code for the EmployeeID field. 
            int hashProductCode = obj.EmployeeID.GetHashCode();

            //Calculate the hash code for the product. 
            return  hashProductCode;
        }
    }
}
