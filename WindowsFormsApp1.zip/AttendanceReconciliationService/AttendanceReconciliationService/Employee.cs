﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 namespace AttendanceReconciliationService
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string Login { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? PracticeID { get; set; }
        public string PracticeName { get; set; }
        public int? RegionID { get; set; }
        public string RegionName { get; set; }
        public string ReportsToID { get; set; }


    }
}
