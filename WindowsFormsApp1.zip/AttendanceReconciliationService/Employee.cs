﻿using System;

public class Employee
{
	public Class1()
	{
	}
}
